package com.evilroot.usbphoneinfo;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.*;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.*;
import android.mtp.MtpDevice;
import android.mtp.MtpDeviceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private static final String ACTION_USB_PERMISSION =
            "com.evilroot.usbphoneinfo.USB_PERMISSION";

    private static final int GREEN = 0xFF19C37D;
    private static final int GREEN_DARK = 0xFF0B3D2E;
    private static final int BLUE = 0xFF5AA9FF;
    private static final int ORANGE = 0xFFFFB020;
    private static final int RED = 0xFFFF5C5C;
    private static final int WHITE = 0xFFF4F7FA;
    private static final int MUTED = 0xFFAAB7C4;
    private static final int PANEL = 0xFF101D2D;
    private static final int PANEL2 = 0xFF16263A;

    private UsbManager usb;
    private LinearLayout deviceList;
    private TextView status;
    private TextView headline;
    private TextView subtitle;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean speakModel = true;
    private boolean connectSound = true;
    private String lastSpokenModel = "";
    private String report = "";
    private final Handler main = new Handler(Looper.getMainLooper());

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                UsbDevice d = getDevice(intent);
                boolean granted = intent.getBooleanExtra(
                        UsbManager.EXTRA_PERMISSION_GRANTED, false);
                if (granted && d != null) {
                    playConnectedTone();
                    scan(false);
                } else {
                    setStatus("● USB CONNECTED • SYSTEM PERMISSION REQUIRED", ORANGE);
                }
                return;
            }

            if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
                playConnectedTone();
                headline.setText("USB DEVICE CONNECTED");
                subtitle.setText("Identifying device…");
                scan(true);
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                playDisconnectedTone();
                headline.setText("USB DEVICE DISCONNECTED");
                subtitle.setText("Waiting for the next device");
                setStatus("●  USB DISCONNECTED", MUTED);
                deviceList.removeAllViews();
                report = "";
            }
        }
    };

    private UsbDevice getDevice(Intent i) {
        if (Build.VERSION.SDK_INT >= 33)
            return i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice.class);
        return i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        usb = (UsbManager)getSystemService(USB_SERVICE);
        deviceList = findViewById(R.id.device_list);
        status = findViewById(R.id.status);
        headline = findViewById(R.id.headline);
        subtitle = findViewById(R.id.subtitle);

        tts = new TextToSpeech(this, this);

        findViewById(R.id.scan).setOnClickListener(v -> scan(false));
        findViewById(R.id.speak).setOnClickListener(v -> speakCurrentModel());
        findViewById(R.id.copy).setOnClickListener(v -> copyReport());
        findViewById(R.id.share).setOnClickListener(v -> shareReport());

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_USB_PERMISSION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(receiver, f, Context.RECEIVER_EXPORTED);
        else
            registerReceiver(receiver, f);

        Intent start = getIntent();
        if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(start.getAction())) {
            playConnectedTone();
        }
        scan(false);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(intent.getAction())) {
            playConnectedTone();
            scan(true);
        }
    }

    @Override public void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override public void onInit(int result) {
        ttsReady = result == TextToSpeech.SUCCESS;
        if (ttsReady) {
            tts.setSpeechRate(0.92f);
            tts.setPitch(1.0f);
        }
    }

    private void playConnectedTone() {
        if (!connectSound) return;
        final android.media.ToneGenerator tg =
                new android.media.ToneGenerator(
                        android.media.AudioManager.STREAM_NOTIFICATION, 85);
        tg.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 120);
        main.postDelayed(() -> tg.release(), 220);
    }

    private void playDisconnectedTone() {
        if (!connectSound) return;
        final android.media.ToneGenerator tg =
                new android.media.ToneGenerator(
                        android.media.AudioManager.STREAM_NOTIFICATION, 85);
        tg.startTone(android.media.ToneGenerator.TONE_PROP_NACK, 150);
        main.postDelayed(() -> tg.release(), 250);
    }

    private void setStatus(String s, int color) {
        status.setText(s);
        status.setTextColor(color);
    }

    private GradientDrawable panel(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        g.setStroke(1, 0x334C6680);
        return g;
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private void scan(boolean fromAttach) {
        Map<String, UsbDevice> devices = usb.getDeviceList();
        deviceList.removeAllViews();
        report = "";

        if (devices.isEmpty()) {
            setStatus("●  NO USB DEVICE DETECTED", MUTED);
            headline.setText("USB PHONE INFO");
            subtitle.setText("Connect an Android phone by USB");
            return;
        }

        setStatus("●  " + devices.size() + " USB DEVICE(S) DETECTED", GREEN);

        for (UsbDevice d : devices.values()) {
            if (usb.hasPermission(d)) {
                render(d);
            } else if (fromAttach || devices.size() == 1) {
                requestPermissionOnce(d);
            } else {
                addPermissionCard(d);
            }
        }
    }

    private void requestPermissionOnce(UsbDevice d) {
        PendingIntent p = PendingIntent.getBroadcast(
                this,
                Math.abs(d.getDeviceId()) + 1000,
                new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        usb.requestPermission(d, p);
        setStatus("●  USB DETECTED • WAITING FOR ANDROID PERMISSION", ORANGE);
    }

    private void addPermissionCard(final UsbDevice d) {
        LinearLayout box = card();
        String name = bestModel(d);
        box.addView(text("PERMISSION NEEDED", 13, ORANGE, true));
        box.addView(text(name, 22, GREEN, true));
        box.addView(text("Android must authorize USB access before deeper diagnostics.", 13, MUTED, false));
        Button b = new Button(this);
        b.setText("ALLOW USB ACCESS");
        b.setOnClickListener(v -> requestPermissionOnce(d));
        box.addView(b);
        deviceList.addView(box, marginParams());
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 18, 18, 18);
        box.setBackground(panel(PANEL, 28));
        return box;
    }

    private LinearLayout.LayoutParams marginParams() {
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 12);
        return lp;
    }

    private void render(UsbDevice d) {
        String model = bestModel(d);
        String manufacturer = bestManufacturer(d);
        String mode = classifyMode(d);

        headline.setText("CONNECTED • " + model);
        subtitle.setText("Automatic technician identification complete");

        LinearLayout box = card();

        TextView connected = text("●  USB DEVICE CONNECTED", 13, GREEN, true);
        box.addView(connected);

        TextView modelView = text(model, 29, GREEN, true);
        modelView.setPadding(0, 6, 0, 2);
        box.addView(modelView);

        box.addView(text(manufacturer, 15, MUTED, false));

        addSection(box, "LIVE STATUS");
        addStatusRow(box, "USB LINK", "CONNECTED", GREEN);
        addStatusRow(box, "PRIMARY MODE", mode, modeColor(mode));
        addStatusRow(box, "ADB", detectAdb(d), detectColor(detectAdb(d)));
        addStatusRow(box, "FASTBOOT", detectFastboot(d), detectColor(detectFastboot(d)));
        addStatusRow(box, "MEDIATEK", detectMtk(d), detectColor(detectMtk(d)));
        addStatusRow(box, "QUALCOMM 9008 / EDL", detectQualcomm(d), detectColor(detectQualcomm(d)));

        addSection(box, "DEVICE IDENTITY");
        addRow(box, "Manufacturer", manufacturer);
        addRow(box, "Model", model);
        addRow(box, "USB path", safe(d.getDeviceName()));
        addRow(box, "VID", hex(d.getVendorId()));
        addRow(box, "PID", hex(d.getProductId()));
        addRow(box, "USB serial", readSerial(d));
        addRow(box, "USB class", usbClass(d.getDeviceClass()));
        addRow(box, "Interfaces", String.valueOf(d.getInterfaceCount()));

        addSection(box, "INTERFACE MAP");
        addRow(box, "Interfaces", interfaceDetails(d));

        addSection(box, "MTP / ANDROID");
        String mtp = mtpInfo(d);
        addRow(box, "MTP", mtp);

        addSection(box, "TECHNICIAN ANALYSIS");
        TextView rec = text(recommendation(d), 14, BLUE, true);
        rec.setPadding(0, 6, 0, 4);
        box.addView(rec);

        deviceList.addView(box, marginParams());

        report += "\n=== USB PHONE INFO • TECHNICIAN PRO ===\n";
        report += "MODEL: " + model + "\n";
        report += "MANUFACTURER: " + manufacturer + "\n";
        report += "USB PATH: " + safe(d.getDeviceName()) + "\n";
        report += "VID: " + hex(d.getVendorId()) + "\n";
        report += "PID: " + hex(d.getProductId()) + "\n";
        report += "USB SERIAL: " + readSerial(d) + "\n";
        report += "PRIMARY MODE: " + mode + "\n";
        report += "ADB: " + detectAdb(d) + "\n";
        report += "FASTBOOT: " + detectFastboot(d) + "\n";
        report += "MEDIATEK: " + detectMtk(d) + "\n";
        report += "QUALCOMM 9008/EDL: " + detectQualcomm(d) + "\n";
        report += "MTP: " + mtp + "\n";
        report += "INTERFACES: " + interfaceDetails(d) + "\n";
        report += "ANALYSIS: " + recommendation(d) + "\n";

        if (speakModel && !model.equals("Unknown Android Device")
                && !model.equals(lastSpokenModel)) {
            lastSpokenModel = model;
            main.postDelayed(this::speakCurrentModel, 350);
        }
    }

    private String bestModel(UsbDevice d) {
        String p = safe(d.getProductName());
        if (!p.equals("Not reported")) return p;
        return "Unknown Android Device";
    }

    private String bestManufacturer(UsbDevice d) {
        String m = safe(d.getManufacturerName());
        return m.equals("Not reported") ? "Android USB device" : m;
    }

    private void speakCurrentModel() {
        if (!ttsReady) return;
        String model = headline.getText().toString();
        int cut = model.indexOf("•");
        if (cut >= 0) model = model.substring(cut + 1).trim();
        if (model.length() == 0 || model.equals("USB PHONE INFO")) return;
        tts.speak(model, TextToSpeech.QUEUE_FLUSH, null, "usb_model");
    }

    private void addSection(LinearLayout p, String s) {
        TextView t = text(s, 14, BLUE, true);
        t.setPadding(0, 14, 0, 7);
        p.addView(t);
    }

    private void addRow(LinearLayout p, String key, String value) {
        TextView t = text(key + "\n" + value, 13, WHITE, false);
        t.setPadding(0, 5, 0, 7);
        p.addView(t);
    }

    private void addStatusRow(LinearLayout p, String key, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(11, 9, 11, 9);
        row.setBackground(panel(PANEL2, 14));

        TextView k = text(key, 12, MUTED, true);
        TextView v = text(value, 13, color, true);
        row.addView(k, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(v);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 3, 0, 3);
        p.addView(row, lp);
    }

    private String safe(String s) {
        return TextUtils.isEmpty(s) ? "Not reported" : s;
    }

    private String readSerial(UsbDevice d) {
        try { return safe(d.getSerialNumber()); }
        catch (Exception e) { return "Protected / unavailable"; }
    }

    private String hex(int x) {
        return String.format(Locale.US, "0x%04X (%d)", x & 0xFFFF, x);
    }

    private String usbClass(int c) {
        switch (c) {
            case UsbConstants.USB_CLASS_STILL_IMAGE: return "Still Image / MTP";
            case UsbConstants.USB_CLASS_COMM: return "Communications";
            case UsbConstants.USB_CLASS_CDC_DATA: return "CDC Data";
            case UsbConstants.USB_CLASS_HID: return "HID";
            case UsbConstants.USB_CLASS_VENDOR_SPEC: return "Vendor Specific";
            default: return "0x" + Integer.toHexString(c);
        }
    }

    private String classifyMode(UsbDevice d) {
        if (isQualcomm(d)) return "QUALCOMM 9008 / EDL";
        if (isMtkService(d)) return "MEDIATEK PRELOADER / BROM";
        if (hasAdb(d)) return "ADB / ANDROID";
        if (looksFastboot(d)) return "FASTBOOT";
        if (hasMtp(d)) return "MTP / PTP";
        return "USB / VENDOR";
    }

    private boolean hasMtp(UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++)
            if (d.getInterface(i).getInterfaceClass() == UsbConstants.USB_CLASS_STILL_IMAGE)
                return true;
        return false;
    }

    private boolean hasAdb(UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface u = d.getInterface(i);
            if (u.getInterfaceClass() == 0xFF &&
                    u.getInterfaceSubclass() == 0x42 &&
                    u.getInterfaceProtocol() == 0x01 &&
                    u.getEndpointCount() >= 2) return true;
        }
        return false;
    }

    private boolean looksFastboot(UsbDevice d) {
        int v = d.getVendorId(), p = d.getProductId();
        return v == 0x18D1 &&
                (p == 0x4EE0 || p == 0x4EE1 || p == 0x4EE2 || p == 0x4EE7);
    }

    private boolean isQualcomm(UsbDevice d) {
        return d.getVendorId() == 0x05C6 && d.getProductId() == 0x9008;
    }

    private boolean isMtkService(UsbDevice d) {
        if (d.getVendorId() != 0x0E8D) return false;
        int p = d.getProductId();
        if (p == 0x2008 || p == 0x2000) return false;
        return p == 0x0003 || p == 0x0004 || p == 0x0005 ||
                p == 0x2001 || p == 0x2002 || p == 0x2003 ||
                p == 0x2004 || p == 0x2007 || p == 0x200B ||
                hasVendorInterface(d);
    }

    private boolean hasVendorInterface(UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++)
            if (d.getInterface(i).getInterfaceClass() == 0xFF) return true;
        return false;
    }

    private String detectAdb(UsbDevice d) {
        return hasAdb(d) ? "INTERFACE DETECTED • AUTHORIZATION REQUIRED" : "Not detected";
    }

    private String detectFastboot(UsbDevice d) {
        return looksFastboot(d) ? "Detected from USB identifiers" : "Not confirmed";
    }

    private String detectQualcomm(UsbDevice d) {
        return isQualcomm(d) ? "DETECTED • VID 05C6 / PID 9008" : "Not detected";
    }

    private String detectMtk(UsbDevice d) {
        if (isMtkService(d)) return "POSSIBLE SERVICE INTERFACE";
        if (d.getVendorId() == 0x0E8D)
            return "MediaTek USB vendor • Android/MTP PID";
        return "Not detected";
    }

    private int modeColor(String mode) {
        String x = mode.toUpperCase(Locale.US);
        if (x.contains("QUALCOMM") || x.contains("MEDIATEK")) return ORANGE;
        if (x.contains("VENDOR")) return MUTED;
        return GREEN;
    }

    private int detectColor(String value) {
        String x = value.toUpperCase(Locale.US);
        if (x.contains("DETECTED") && !x.contains("NOT DETECTED")
                && !x.contains("NOT CONFIRMED")) return GREEN;
        if (x.contains("POSSIBLE") || x.contains("NOT CONFIRMED")
                || x.contains("REQUIRED")) return ORANGE;
        return MUTED;
    }

    private String interfaceDetails(UsbDevice d) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface u = d.getInterface(i);
            s.append("#").append(i)
                    .append(" class=").append(String.format(Locale.US, "0x%02X", u.getInterfaceClass()))
                    .append(" sub=").append(String.format(Locale.US, "0x%02X", u.getInterfaceSubclass()))
                    .append(" proto=").append(String.format(Locale.US, "0x%02X", u.getInterfaceProtocol()))
                    .append(" ep=").append(u.getEndpointCount());
            if (i + 1 < d.getInterfaceCount()) s.append(" | ");
        }
        return s.toString();
    }

    private String mtpInfo(UsbDevice d) {
        if (!hasMtp(d)) return "Not detected";
        UsbDeviceConnection con = null;
        MtpDevice mtp = null;
        try {
            con = usb.openDevice(d);
            if (con == null) return "Detected • connection unavailable";
            mtp = new MtpDevice(d);
            if (!mtp.open(con)) return "Detected • MTP open failed";
            MtpDeviceInfo info = mtp.getDeviceInfo();
            if (info == null) return "Detected • no device info";
            return "Detected • " + safe(info.getManufacturer()) + " • "
                    + safe(info.getModel()) + " • Android USB/MTP";
        } catch (Exception e) {
            return "Detected • information unavailable";
        } finally {
            try { if (mtp != null) mtp.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }

    private String recommendation(UsbDevice d) {
        if (isQualcomm(d))
            return "QUALCOMM 9008 confirmed. Open the diagnostics panel for interface details.";
        if (isMtkService(d))
            return "MediaTek service interface detected. Verify the actual Preloader/BROM state before any service operation.";
        if (hasAdb(d))
            return "ADB interface detected. Authorize USB debugging for deeper, non-bypass diagnostics.";
        if (looksFastboot(d))
            return "Fastboot identifiers detected. Read bootloader information before selecting an operation.";
        if (hasMtp(d))
            return "Normal Android/MTP connection. Enable USB debugging if deeper authorized ADB diagnostics are required.";
        return "USB device detected. Inspect VID/PID and interface descriptors before choosing a service workflow.";
    }

    private void copyReport() {
        if (report.isEmpty()) {
            Toast.makeText(this, "Nothing to copy.", Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.ClipboardManager cm =
                (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("USB Phone Info Technician Report", report));
        Toast.makeText(this, "Technician report copied.", Toast.LENGTH_SHORT).show();
    }

    private void shareReport() {
        if (report.isEmpty()) {
            Toast.makeText(this, "Nothing to share.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "USB Phone Info • Technician Pro Report");
        i.putExtra(Intent.EXTRA_TEXT, report);
        startActivity(Intent.createChooser(i, "Share technician report"));
    }
}
