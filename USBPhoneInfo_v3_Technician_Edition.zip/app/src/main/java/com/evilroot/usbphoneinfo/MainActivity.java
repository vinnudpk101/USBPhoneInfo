package com.evilroot.usbphoneinfo;

import android.app.*;
import android.content.*;
import android.hardware.usb.*;
import android.mtp.MtpDevice;
import android.mtp.MtpDeviceInfo;
import android.os.*;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String ACTION = "com.evilroot.usbphoneinfo.USB_PERMISSION";
    UsbManager manager;
    LinearLayout cards;
    TextView status;
    String report = "";

    final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (ACTION.equals(a)) {
                UsbDevice d = getDevice(i);
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && d != null) render(d);
                else status.setText("USB permission denied.");
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)
                    || UsbManager.ACTION_USB_DEVICE_DETACHED.equals(a)) {
                scan();
            }
        }
    };

    UsbDevice getDevice(Intent i) {
        if (Build.VERSION.SDK_INT >= 33) return i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice.class);
        return i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        manager = (UsbManager)getSystemService(USB_SERVICE);
        cards = findViewById(R.id.cards);
        status = findViewById(R.id.status);

        findViewById(R.id.scan).setOnClickListener(v -> scan());
        findViewById(R.id.copy).setOnClickListener(v -> copyReport());
        findViewById(R.id.share).setOnClickListener(v -> shareReport());

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(receiver, f);

        scan();
    }

    @Override public void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    void scan() {
        cards.removeAllViews();
        report = "";
        Map<String,UsbDevice> ds = manager.getDeviceList();

        if (ds.isEmpty()) {
            status.setText("No USB device detected.");
            return;
        }

        status.setText("Detected " + ds.size() + " USB device(s).");

        for (UsbDevice d : ds.values()) {
            if (manager.hasPermission(d)) render(d);
            else {
                PendingIntent p = PendingIntent.getBroadcast(
                        this,
                        Math.abs(d.getDeviceId()),
                        new Intent(ACTION).setPackage(getPackageName()),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                manager.requestPermission(d, p);
            }
        }
    }

    void render(UsbDevice d) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 18, 18, 18);
        box.setBackgroundColor(0xFFF5F7FA);

        String mode = classifyMode(d);

        addHeader(box, "DEVICE / USB");
        add(box, "Device path", safe(d.getDeviceName()));
        add(box, "Manufacturer", safe(d.getManufacturerName()));
        add(box, "Product / Model", safe(d.getProductName()));
        add(box, "VID", hex(d.getVendorId()));
        add(box, "PID", hex(d.getProductId()));
        add(box, "USB class", usbClass(d.getDeviceClass()));
        add(box, "Interfaces", String.valueOf(d.getInterfaceCount()));
        add(box, "USB serial", readSerial(d));

        addHeader(box, "MODE DETECTION");
        add(box, "Primary USB mode", mode);
        add(box, "MTP / PTP", mtp(d));
        add(box, "ADB", detectAdb(d));
        add(box, "Fastboot", detectFastboot(d));
        add(box, "Qualcomm 9008 / EDL", detectQualcomm(d));
        add(box, "MediaTek Preloader / BROM", detectMtkService(d));

        addHeader(box, "INTERFACES");
        add(box, "Interface details", interfaceDetails(d));

        addHeader(box, "TECHNICIAN RESULT");
        add(box, "Recommended next check", recommendation(d));

        cards.addView(box, new LinearLayout.LayoutParams(-1, -2));
        report += "\n=== USB PHONE INFO TECHNICIAN REPORT ===\n" + textOf(box) + "\n";
    }

    void addHeader(LinearLayout p, String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(17);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, 12, 0, 4);
        p.addView(t);
    }

    void add(LinearLayout p, String k, String v) {
        TextView t = new TextView(this);
        t.setText(k + ": " + v);
        t.setTextSize(15);
        t.setPadding(0, 5, 0, 5);
        p.addView(t);
    }

    String textOf(View v) {
        if (!(v instanceof ViewGroup)) return "";
        StringBuilder s = new StringBuilder();
        ViewGroup g = (ViewGroup)v;
        for (int i=0; i<g.getChildCount(); i++) {
            View x = g.getChildAt(i);
            if (x instanceof TextView) s.append(((TextView)x).getText()).append('\n');
        }
        return s.toString();
    }

    String safe(String s) { return TextUtils.isEmpty(s) ? "Not reported" : s; }

    String readSerial(UsbDevice d) {
        try { return safe(d.getSerialNumber()); }
        catch (Exception e) { return "Protected / unavailable"; }
    }

    String hex(int x) { return String.format(Locale.US, "0x%04X (%d)", x & 65535, x); }

    String usbClass(int c) {
        switch (c) {
            case UsbConstants.USB_CLASS_VENDOR_SPEC: return "Vendor Specific";
            case UsbConstants.USB_CLASS_STILL_IMAGE: return "Still Image / MTP";
            case UsbConstants.USB_CLASS_COMM: return "Communications";
            case UsbConstants.USB_CLASS_CDC_DATA: return "CDC Data";
            case UsbConstants.USB_CLASS_HID: return "HID";
            default: return "0x" + Integer.toHexString(c);
        }
    }

    String classifyMode(UsbDevice d) {
        if (isQualcomm(d)) return "QUALCOMM 9008 / EDL";
        if (isMtkService(d)) return "MEDIATEK PRELOADER / BROM";
        if (hasAdbInterface(d)) return "ADB / ANDROID";
        if (looksFastboot(d)) return "FASTBOOT";
        if (hasMtpInterface(d)) return "MTP / PTP";
        return "USB / VENDOR MODE";
    }

    boolean hasMtpInterface(UsbDevice d) {
        for (int i=0; i<d.getInterfaceCount(); i++)
            if (d.getInterface(i).getInterfaceClass() == UsbConstants.USB_CLASS_STILL_IMAGE) return true;
        return false;
    }

    boolean hasAdbInterface(UsbDevice d) {
        for (int i=0; i<d.getInterfaceCount(); i++) {
            UsbInterface u = d.getInterface(i);
            if (u.getInterfaceClass() == 0xFF && u.getInterfaceSubclass() == 0x42
                    && u.getInterfaceProtocol() == 0x01 && u.getEndpointCount() >= 2) return true;
        }
        return false;
    }

    boolean looksFastboot(UsbDevice d) {
        int v = d.getVendorId(), p = d.getProductId();
        if (v == 0x18D1 && (p == 0x4EE0 || p == 0x4EE1 || p == 0x4EE2 || p == 0x4EE7)) return true;
        if (v == 0x18D1 && d.getDeviceClass() == UsbConstants.USB_CLASS_VENDOR_SPEC) return true;
        return false;
    }

    boolean isQualcomm(UsbDevice d) {
        return d.getVendorId() == 0x05C6 && d.getProductId() == 0x9008;
    }

    boolean isMtkService(UsbDevice d) {
        if (d.getVendorId() != 0x0E8D) return false;
        int p = d.getProductId();
        // Common MediaTek preloader/BROM/VCOM PIDs. 0x2008 is commonly Android/MTP,
        // so it is deliberately NOT classified as a service mode.
        if (p == 0x2008 || p == 0x2000) return false;
        return p == 0x0003 || p == 0x0004 || p == 0x0005
                || p == 0x2001 || p == 0x2002 || p == 0x2003
                || p == 0x2004 || p == 0x2007 || p == 0x200B
                || hasVendorInterface(d);
    }

    boolean hasVendorInterface(UsbDevice d) {
        for (int i=0; i<d.getInterfaceCount(); i++)
            if (d.getInterface(i).getInterfaceClass() == 0xFF) return true;
        return false;
    }

    String detectAdb(UsbDevice d) {
        if (!hasAdbInterface(d)) return "Not detected";
        return "ADB interface detected; authorization required for device commands";
    }

    String detectFastboot(UsbDevice d) {
        return looksFastboot(d) ? "Possible / detected from USB identifiers" : "Not confirmed";
    }

    String detectQualcomm(UsbDevice d) {
        return isQualcomm(d) ? "DETECTED (VID 05C6 / PID 9008)" : "Not detected";
    }

    String detectMtkService(UsbDevice d) {
        if (isMtkService(d))
            return "POSSIBLE / detected MediaTek service interface (VID 0E8D)";
        if (d.getVendorId() == 0x0E8D)
            return "MediaTek USB vendor ID detected; current PID looks like Android/MTP, not service mode";
        return "Not detected";
    }

    String interfaceDetails(UsbDevice d) {
        StringBuilder s = new StringBuilder();
        for (int i=0; i<d.getInterfaceCount(); i++) {
            UsbInterface u = d.getInterface(i);
            s.append("#").append(i)
             .append(" class=").append(String.format(Locale.US, "0x%02X", u.getInterfaceClass()))
             .append(" subclass=").append(String.format(Locale.US, "0x%02X", u.getInterfaceSubclass()))
             .append(" protocol=").append(String.format(Locale.US, "0x%02X", u.getInterfaceProtocol()))
             .append(" endpoints=").append(u.getEndpointCount());
            if (i + 1 < d.getInterfaceCount()) s.append(" | ");
        }
        return s.toString();
    }

    String mtp(UsbDevice d) {
        if (!hasMtpInterface(d)) return "Not detected";
        UsbDeviceConnection con = null;
        MtpDevice m = null;
        try {
            con = manager.openDevice(d);
            if (con == null) return "Detected, connection unavailable";
            m = new MtpDevice(d);
            if (!m.open(con)) return "Detected, MTP open failed";
            MtpDeviceInfo x = m.getDeviceInfo();
            if (x == null) return "Detected, no device info";
            return "Detected | " + safe(x.getManufacturer()) + " | "
                    + safe(x.getModel()) + " | Android USB/MTP";
        } catch (Exception e) {
            return "Detected, unavailable";
        } finally {
            try { if (m != null) m.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }

    String recommendation(UsbDevice d) {
        if (isQualcomm(d)) return "Use Qualcomm/EDL diagnostics; USB 9008 is confirmed.";
        if (isMtkService(d)) return "Check MediaTek Preloader/BROM/VCOM connection.";
        if (hasAdbInterface(d)) return "Authorize USB debugging if Android prompts for RSA access.";
        if (looksFastboot(d)) return "Use fastboot diagnostics; inspect exposed bootloader identifiers.";
        if (hasMtpInterface(d)) return "Normal Android/MTP connection; enable USB debugging for deeper ADB diagnostics.";
        return "Inspect USB VID/PID and interface class before selecting a service mode.";
    }

    void copyReport() {
        if (report.length() == 0) {
            Toast.makeText(this, "Nothing to copy.", Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.ClipboardManager cm =
                (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("USB Phone Info", report));
        Toast.makeText(this, "Technician report copied.", Toast.LENGTH_SHORT).show();
    }

    void shareReport() {
        if (report.length() == 0) {
            Toast.makeText(this, "Nothing to share.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "USB Phone Info Technician Report");
        i.putExtra(Intent.EXTRA_TEXT, report);
        startActivity(Intent.createChooser(i, "Share technician report"));
    }
}
