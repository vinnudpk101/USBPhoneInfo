# USB Phone Info — Technician Edition 3.0

Android USB-host diagnostic utility for mobile technicians.

## Features
- USB device attach/detach scanning
- Manufacturer, product/model, VID/PID, USB class, interface count and serial
- MTP/PTP identification and MTP device information
- ADB interface detection
- Fastboot heuristic detection
- Qualcomm HS-USB QDLoader 9008 / EDL detection
- MediaTek service-interface heuristic detection
- Detailed USB interface class/subclass/protocol/endpoint information
- Technician-oriented recommendation
- Copy report
- Share report
- Automatic USB permission flow

## Important limitations
ADB commands require USB debugging and an authorized ADB key. This version detects the ADB USB interface but does not bypass Android authorization.

Fastboot, Qualcomm and MediaTek identification is based on USB identifiers/interfaces exposed by the connected device. A USB VID/PID alone cannot guarantee the exact chipset or model.

A completely dead phone may expose only USB identifiers, or nothing at all.

## Build
Use Gradle 8.7 with JDK 17 and Android SDK platform/build-tools 35.
