# USB Phone Info — Technician Edition 4.0

Colourful technician-focused Android USB host diagnostic utility.

## UI improvements
- Modern gradient background
- Clean sans-serif typography
- Connected model prominently highlighted in green
- Colour-coded USB mode status
- Technician result card
- Copy and Share report actions

## Diagnostics
- USB device attach/detach scanning
- Manufacturer, product/model, VID/PID, USB class, interfaces and serial
- MTP/PTP identification
- ADB interface detection
- Fastboot heuristic detection
- Qualcomm HS-USB QDLoader 9008 / EDL detection
- MediaTek service-interface heuristic detection
- Detailed USB interface information
- Technician recommendation
- Automatic USB permission flow

## Important limitations
ADB commands require USB debugging and an authorized ADB key. This app detects the ADB USB interface but does not bypass Android authorization.

Fastboot, Qualcomm and MediaTek identification is based on USB identifiers/interfaces exposed by the connected device. A USB VID/PID alone cannot guarantee an exact chipset or model.

A completely dead phone may expose only USB identifiers, or nothing at all.

## Build
Gradle 8.7, JDK 17, Android SDK platform/build-tools 35.


## Technician Command Center 5.0
The v5 build adds a dark command-center presentation, prominent green device identity, full-scan emphasis, and a dedicated command-center information panel while preserving the working USB detection engine from v4.
