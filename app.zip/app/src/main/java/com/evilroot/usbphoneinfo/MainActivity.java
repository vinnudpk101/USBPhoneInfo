package com.evilroot.usbphoneinfo;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.mtp.MtpDevice;
import android.mtp.MtpDeviceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private static final String ACTION_USB_PERMISSION =
            "com.evilroot.usbphoneinfo.USB_PERMISSION";

    private static final int GREEN = Color.rgb(25, 195, 125);
    private static final int GREEN_DARK = Color.rgb(11, 61, 46);
    private static final int BLUE = Color.rgb(90, 169, 255);
    private static final int ORANGE = Color.rgb(255, 176, 32);
    private static final int RED = Color.rgb(255, 92, 92);
    private static final int WHITE = Color.rgb(244, 247, 250);
    private static final int MUTED = Color.rgb(170, 183, 196);
    private static final int PANEL = Color.rgb(16, 29, 45);
    private static final int PANEL2 = Color.rgb(22, 38, 58);

    private UsbManager usb;
    private LinearLayout deviceList;
    private TextView status;
    private TextView headline;
    private TextView subtitle;
    private TextView monitorStatus;
    private TextView historyView;

    private TextToSpeech tts;
    private boolean ttsReady;
    private String lastSpokenModel = "";
    private String currentModel = "";
    private String currentFingerprint = "";
    private String report = "";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private final Set<String> knownDevices = new HashSet<>();
    private final Map<String, UsbDevice> liveDevices = new HashMap<>();
    private final ArrayList<String> history = new ArrayList<>();

    private boolean monitorRunning = false;
    private boolean permissionRequestInFlight = false;
    private int lastRenderedDeviceCount = -1;

    private final Runnable usbMonitor = new Runnable() {
        @Override public void run() {
            if (!monitorRunning) return;
            reconcileUsbDevices();
            main.postDelayed(this, 700);
        }
    };

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (ACTION_USB_PERMISSION.equals(action)) {
                permissionRequestInFlight = false;
                UsbDevice d = getDevice(intent);
                boolean granted = intent.getBooleanExtra(
                        UsbManager.EXTRA_PERMISSION_GRANTED, false);

                if (granted && d != null) {
                    appendHistory("USB permission granted: " + displayName(d));
                    scanCurrentDevice(d, true);
                } else {
                    setStatus("● USB ACCESS NOT GRANTED", ORANGE);
                    addPermissionCard(d);
                }
                return;
            }

            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                UsbDevice d = getDevice(intent);
                if (d != null) {
                    String fp = fingerprint(d);
                    if (knownDevices.remove(fp)) {
                        liveDevices.remove(fp);
                        playSound(R.raw.usb_disconnected);
                        appendHistory("USB disconnected: " + displayName(d));
                    }
                }
                reconcileUsbDevices();
            }
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        usb = (UsbManager) getSystemService(Context.USB_SERVICE);

        deviceList = findViewById(R.id.device_list);
        status = findViewById(R.id.status);
        headline = findViewById(R.id.headline);
        subtitle = findViewById(R.id.subtitle);
        monitorStatus = findViewById(R.id.monitor_status);
        historyView = findViewById(R.id.history);

        tts = new TextToSpeech(this, this);

        findViewById(R.id.scan).setOnClickListener(v -> fullScan());
        findViewById(R.id.speak).setOnClickListener(v -> speakCurrentModel());
        findViewById(R.id.copy).setOnClickListener(v -> copyReport());
        findViewById(R.id.share).setOnClickListener(v -> shareReport());
        findViewById(R.id.clear_history).setOnClickListener(v -> {
            history.clear();
            updateHistory();
        });

        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(usbReceiver, filter);
        }

        appendHistory("Technician monitor initialized.");
    }

    @Override
    protected void onResume() {
        super.onResume();
        startMonitor();
    }

    @Override
    protected void onPause() {
        stopMonitor();
        super.onPause();
    }

    private void startMonitor() {
        if (monitorRunning) return;
        monitorRunning = true;
        monitorStatus.setText("● LIVE USB MONITOR: ACTIVE");
        monitorStatus.setTextColor(GREEN);
        reconcileUsbDevices();
        main.post(usbMonitor);
    }

    private void stopMonitor() {
        monitorRunning = false;
        main.removeCallbacks(usbMonitor);
        if (monitorStatus != null) {
            monitorStatus.setText("● LIVE USB MONITOR: PAUSED");
            monitorStatus.setTextColor(MUTED);
        }
    }

    private void reconcileUsbDevices() {
        if (usb == null) return;

        Map<String, UsbDevice> devices = usb.getDeviceList();
        Set<String> current = new HashSet<>();

        for (UsbDevice d : devices.values()) {
            String fp = fingerprint(d);
            current.add(fp);
            liveDevices.put(fp, d);

            if (!knownDevices.contains(fp)) {
                knownDevices.add(fp);
                onDeviceConnected(d);
            }
        }

        Set<String> removed = new HashSet<>(knownDevices);
        removed.removeAll(current);

        for (String fp : removed) {
            UsbDevice old = liveDevices.remove(fp);
            knownDevices.remove(fp);
            if (old != null) {
                playSound(R.raw.usb_disconnected);
                appendHistory("USB disconnected: " + displayName(old));
            }
        }

        if (devices.isEmpty()) {
            if (lastRenderedDeviceCount != 0) {
                setStatus("● NO USB DEVICE DETECTED", MUTED);
                headline.setText("USB PHONE INFO");
                subtitle.setText("Connect an Android phone by USB");
                deviceList.removeAllViews();
                currentModel = "";
                currentFingerprint = "";
                report = "";
            }
            lastRenderedDeviceCount = 0;
            return;
        }

        if (devices.size() == 1) {
            // A newly connected device is already scanned by onDeviceConnected().
            // Avoid re-opening MTP and rebuilding the UI every 700 ms.
            UsbDevice d = devices.values().iterator().next();
            String fp = fingerprint(d);
            if (!fp.equals(currentFingerprint)) {
                scanCurrentDevice(d, false);
            }
        } else {
            if (lastRenderedDeviceCount != devices.size()) {
                renderMultiple(devices);
            }
        }
        lastRenderedDeviceCount = devices.size();
    }

    private void onDeviceConnected(UsbDevice d) {
        playSound(R.raw.usb_connected);
        appendHistory("USB connected: " + displayName(d));
        headline.setText("USB DEVICE CONNECTED");
        subtitle.setText("Reading USB identity…");
        setStatus("● USB CONNECTED • IDENTIFYING", GREEN);

        if (usb.hasPermission(d)) {
            scanCurrentDevice(d, true);
        } else {
            requestPermissionOnce(d);
        }
    }

    private void requestPermissionOnce(UsbDevice d) {
        if (d == null || permissionRequestInFlight) return;
        permissionRequestInFlight = true;

        Intent intent = new Intent(ACTION_USB_PERMISSION)
                .setPackage(getPackageName());

        PendingIntent pi = PendingIntent.getBroadcast(
                this,
                Math.abs(fingerprint(d).hashCode()),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        usb.requestPermission(d, pi);
        setStatus("● USB CONNECTED • ANDROID ACCESS REQUIRED", ORANGE);
    }

    private void scanCurrentDevice(UsbDevice d, boolean speakAfter) {
        if (d == null) return;

        String fp = fingerprint(d);
        currentFingerprint = fp;

        if (!usb.hasPermission(d)) {
            addPermissionCard(d);
            return;
        }

        String model = usbProductName(d);
        String manufacturer = usbManufacturerName(d);

        currentModel = model;
        renderDevice(d, model, manufacturer);

        final boolean speak = speakAfter;
        worker.submit(() -> {
            String mtpModel = null;
            String mtpManufacturer = null;

            if (hasMtp(d)) {
                MtpIdentity identity = readMtpIdentity(d);
                if (identity != null) {
                    mtpModel = identity.model;
                    mtpManufacturer = identity.manufacturer;
                }
            }

            final String finalMtpModel = mtpModel;
            final String finalMtpManufacturer = mtpManufacturer;

            main.post(() -> {
                String resolvedModel = firstUseful(
                        finalMtpModel,
                        model,
                        manufacturer + " USB Device");

                String resolvedManufacturer = firstUseful(
                        finalMtpManufacturer,
                        manufacturer,
                        "Android USB Device");

                currentModel = cleanModel(resolvedModel);
                renderDevice(d, currentModel, resolvedManufacturer);
                if (speak) {
                    speakModelAfterConnection(currentModel);
                }
            });
        });
    }

    private void renderDevice(UsbDevice d, String model, String manufacturer) {
        deviceList.removeAllViews();

        String mode = classifyMode(d);
        headline.setText("CONNECTED • " + model);
        subtitle.setText("Automatic USB identification • read-only diagnostics");
        setStatus("● 1 USB DEVICE DETECTED • " + mode, GREEN);

        LinearLayout box = card();

        box.addView(text("●  USB DEVICE CONNECTED", 13, GREEN, true));

        TextView modelView = text(model, 30, GREEN, true);
        modelView.setPadding(0, 7, 0, 2);
        box.addView(modelView);
        box.addView(text(manufacturer, 15, MUTED, false));

        addSection(box, "LIVE MONITOR");
        addStatusRow(box, "USB LINK", "CONNECTED", GREEN);
        addStatusRow(box, "PRIMARY MODE", mode, modeColor(mode));
        addStatusRow(box, "ADB INTERFACE", adbStatus(d), detectColor(adbStatus(d)));
        addStatusRow(box, "FASTBOOT", fastbootStatus(d), detectColor(fastbootStatus(d)));
        addStatusRow(box, "MEDIATEK", mediatekStatus(d), detectColor(mediatekStatus(d)));
        addStatusRow(box, "QUALCOMM 9008 / EDL", qualcommStatus(d),
                detectColor(qualcommStatus(d)));

        addSection(box, "DEVICE IDENTITY");
        addRow(box, "Manufacturer", manufacturer);
        addRow(box, "Model", model);
        addRow(box, "USB path", safe(d.getDeviceName()));
        addRow(box, "VID", hex(d.getVendorId()));
        addRow(box, "PID", hex(d.getProductId()));
        addRow(box, "USB version", safe(d.getVersion()));
        addRow(box, "USB serial", readSerial(d));
        addRow(box, "Device class", usbClass(d.getDeviceClass()));
        addRow(box, "Device subclass", hexByte(d.getDeviceSubclass()));
        addRow(box, "Device protocol", hexByte(d.getDeviceProtocol()));
        addRow(box, "Configurations", String.valueOf(d.getConfigurationCount()));
        addRow(box, "Interfaces", String.valueOf(d.getInterfaceCount()));

        addSection(box, "INTERFACE / ENDPOINT MAP");
        addRow(box, "USB topology", interfaceDetails(d));

        addSection(box, "MTP / ANDROID IDENTITY");
        addRow(box, "MTP", hasMtp(d) ? "Detected • detailed identity queried when supported" : "Not detected");
        addRow(box, "ADB", hasAdb(d)
                ? "Interface present • authorization state is controlled by Android"
                : "Not detected");

        addSection(box, "TECHNICIAN ANALYSIS");
        TextView rec = text(recommendation(d), 14, BLUE, true);
        rec.setPadding(0, 6, 0, 4);
        box.addView(rec);

        addSection(box, "SAFETY / LIMITS");
        box.addView(text(
                "This edition performs USB identification and read-only diagnostics. "
                        + "It does not bypass Android authorization, bootloader security, "
                        + "or device security controls.",
                12, MUTED, false));

        deviceList.addView(box, marginParams());

        report = buildReport(d, model, manufacturer, mode);
    }

    private void renderMultiple(Map<String, UsbDevice> devices) {
        deviceList.removeAllViews();
        setStatus("● " + devices.size() + " USB DEVICE(S) DETECTED", GREEN);
        headline.setText("MULTIPLE USB DEVICES");
        subtitle.setText("Select the device information below");

        for (UsbDevice d : devices.values()) {
            LinearLayout box = card();
            String model = usbProductName(d);
            box.addView(text(model, 22, GREEN, true));
            box.addView(text(usbManufacturerName(d), 14, MUTED, false));
            addRow(box, "VID:PID", hex(d.getVendorId()) + " : " + hex(d.getProductId()));
            addRow(box, "Mode", classifyMode(d));
            Button b = new Button(this);
            b.setText("OPEN DIAGNOSTICS");
            b.setOnClickListener(v -> {
                if (usb.hasPermission(d)) scanCurrentDevice(d, true);
                else requestPermissionOnce(d);
            });
            box.addView(b);
            deviceList.addView(box, marginParams());
        }
    }

    private void addPermissionCard(UsbDevice d) {
        deviceList.removeAllViews();
        if (d == null) return;

        LinearLayout box = card();
        box.addView(text("ANDROID USB ACCESS REQUIRED", 15, ORANGE, true));
        box.addView(text(displayName(d), 24, GREEN, true));
        box.addView(text(
                "Android has not granted this app access to this USB device yet. "
                        + "Tap once to request access. Android controls this permission.",
                13, MUTED, false));

        Button b = new Button(this);
        b.setText("ALLOW USB ACCESS");
        b.setOnClickListener(v -> requestPermissionOnce(d));
        box.addView(b);

        deviceList.addView(box, marginParams());
    }

    private String buildReport(UsbDevice d, String model, String manufacturer, String mode) {
        StringBuilder r = new StringBuilder();
        r.append("=== USB PHONE INFO • ADVANCED TECHNICIAN 11X ===\n");
        r.append("MODEL: ").append(model).append('\n');
        r.append("MANUFACTURER: ").append(manufacturer).append('\n');
        r.append("USB PATH: ").append(safe(d.getDeviceName())).append('\n');
        r.append("VID: ").append(hex(d.getVendorId())).append('\n');
        r.append("PID: ").append(hex(d.getProductId())).append('\n');
        r.append("USB VERSION: ").append(safe(d.getVersion())).append('\n');
        r.append("USB SERIAL: ").append(readSerial(d)).append('\n');
        r.append("PRIMARY MODE: ").append(mode).append('\n');
        r.append("ADB: ").append(adbStatus(d)).append('\n');
        r.append("FASTBOOT: ").append(fastbootStatus(d)).append('\n');
        r.append("MEDIATEK: ").append(mediatekStatus(d)).append('\n');
        r.append("QUALCOMM 9008/EDL: ").append(qualcommStatus(d)).append('\n');
        r.append("MTP: ").append(hasMtp(d) ? "Detected" : "Not detected").append('\n');
        r.append("CONFIGURATIONS: ").append(d.getConfigurationCount()).append('\n');
        r.append("INTERFACES: ").append(d.getInterfaceCount()).append('\n');
        r.append("INTERFACE MAP: ").append(interfaceDetails(d)).append('\n');
        r.append("ANALYSIS: ").append(recommendation(d)).append('\n');
        return r.toString();
    }

    private MtpIdentity readMtpIdentity(UsbDevice d) {
        UsbDeviceConnection con = null;
        MtpDevice mtp = null;
        try {
            con = usb.openDevice(d);
            if (con == null) return null;

            mtp = new MtpDevice(d);
            if (!mtp.open(con)) return null;

            MtpDeviceInfo info = mtp.getDeviceInfo();
            if (info == null) return null;

            return new MtpIdentity(
                    safe(info.getModel()),
                    safe(info.getManufacturer()));
        } catch (Exception ignored) {
            return null;
        } finally {
            try { if (mtp != null) mtp.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }

    private static class MtpIdentity {
        final String model;
        final String manufacturer;
        MtpIdentity(String model, String manufacturer) {
            this.model = model;
            this.manufacturer = manufacturer;
        }
    }

    private void speakModelAfterConnection(String model) {
        if (TextUtils.isEmpty(model) || model.equals("Unknown Android Device")) return;
        if (model.equals(lastSpokenModel)) return;

        lastSpokenModel = model;
        main.postDelayed(() -> {
            if (ttsReady) {
                tts.speak(model + " connected",
                        TextToSpeech.QUEUE_FLUSH, null, "usb_model_connected");
            }
        }, 500);
    }

    private void speakCurrentModel() {
        if (!ttsReady || TextUtils.isEmpty(currentModel)) {
            Toast.makeText(this, "No model name available yet.", Toast.LENGTH_SHORT).show();
            return;
        }
        tts.speak(currentModel,
                TextToSpeech.QUEUE_FLUSH, null, "manual_model");
    }

    private void playSound(int resourceId) {
        try {
            MediaPlayer mp = MediaPlayer.create(this, resourceId);
            if (mp == null) return;
            mp.setOnCompletionListener(mp2 -> mp2.release());
            mp.start();
        } catch (Exception ignored) {}
    }

    @Override
    public void onInit(int result) {
        ttsReady = result == TextToSpeech.SUCCESS;
        if (ttsReady) {
            tts.setSpeechRate(0.92f);
            tts.setPitch(1.0f);
        }
    }

    private String usbProductName(UsbDevice d) {
        try {
            String p = d.getProductName();
            return cleanModel(p);
        } catch (Exception ignored) {
            return "Unknown USB Device";
        }
    }

    private String usbManufacturerName(UsbDevice d) {
        try {
            String m = d.getManufacturerName();
            return firstUseful(m, "Android USB Device");
        } catch (Exception ignored) {
            return "Android USB Device";
        }
    }

    private String cleanModel(String value) {
        if (TextUtils.isEmpty(value)) return "Unknown USB Device";
        String x = value.trim();
        if (x.equalsIgnoreCase("Not reported")) return "Unknown USB Device";
        return x;
    }

    private String firstUseful(String... values) {
        for (String v : values) {
            if (!TextUtils.isEmpty(v) && !v.equalsIgnoreCase("Not reported")
                    && !v.equalsIgnoreCase("null")) {
                return v.trim();
            }
        }
        return "Unknown USB Device";
    }

    private String displayName(UsbDevice d) {
        String product = usbProductName(d);
        String maker = usbManufacturerName(d);
        if (!product.equals("Unknown USB Device")) return product;
        return maker + " USB Device";
    }

    private String fingerprint(UsbDevice d) {
        String serial;
        try { serial = d.getSerialNumber(); }
        catch (Exception e) { serial = ""; }

        return d.getVendorId() + ":" + d.getProductId() + ":"
                + safe(serial) + ":" + safe(d.getDeviceName());
    }

    private boolean hasMtp(UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            if (d.getInterface(i).getInterfaceClass()
                    == UsbConstants.USB_CLASS_STILL_IMAGE) return true;
        }
        return false;
    }

    private boolean hasAdb(UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface u = d.getInterface(i);
            if (u.getInterfaceClass() == 0xFF
                    && u.getInterfaceSubclass() == 0x42
                    && u.getInterfaceProtocol() == 0x01
                    && u.getEndpointCount() >= 2) return true;
        }
        return false;
    }

    private boolean looksFastboot(UsbDevice d) {
        int v = d.getVendorId();
        int p = d.getProductId();

        // Common public USB identifiers. This is intentionally heuristic.
        return (v == 0x18D1 && (p == 0x4EE0 || p == 0x4EE1
                || p == 0x4EE2 || p == 0x4EE7 || p == 0xD00D))
                || (v == 0x2A70 && p == 0x9011);
    }

    private boolean isQualcomm(UsbDevice d) {
        return d.getVendorId() == 0x05C6 && d.getProductId() == 0x9008;
    }

    private boolean isMtkPreloader(UsbDevice d) {
        return d.getVendorId() == 0x0E8D
                && (d.getProductId() == 0x2000 || d.getProductId() == 0x2001);
    }

    private boolean isMtkVendorDevice(UsbDevice d) {
        return d.getVendorId() == 0x0E8D;
    }

    private String classifyMode(UsbDevice d) {
        if (isQualcomm(d)) return "QUALCOMM 9008 / EDL";
        if (isMtkPreloader(d)) return "MEDIATEK PRELOADER";
        if (hasAdb(d)) return "ADB INTERFACE";
        if (looksFastboot(d)) return "FASTBOOT (HEURISTIC)";
        if (hasMtp(d)) return "MTP / PTP";
        if (isMtkVendorDevice(d)) return "MEDIATEK USB DEVICE";
        return "USB / VENDOR";
    }

    private String adbStatus(UsbDevice d) {
        return hasAdb(d)
                ? "INTERFACE PRESENT • AUTHORIZATION STATE NOT EXPOSED HERE"
                : "Not detected";
    }

    private String fastbootStatus(UsbDevice d) {
        return looksFastboot(d)
                ? "POSSIBLE FASTBOOT • VID/PID MATCH"
                : "Not confirmed";
    }

    private String mediatekStatus(UsbDevice d) {
        if (isMtkPreloader(d))
            return "PRELOADER PID MATCH (0E8D:2000/2001)";
        if (isMtkVendorDevice(d))
            return "MEDIATEK USB VENDOR DETECTED • NOT LOW-LEVEL CONFIRMED";
        return "Not detected";
    }

    private String qualcommStatus(UsbDevice d) {
        return isQualcomm(d)
                ? "CONFIRMED • VID 05C6 / PID 9008"
                : "Not detected";
    }

    private String interfaceDetails(UsbDevice d) {
        StringBuilder s = new StringBuilder();

        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface u = d.getInterface(i);
            s.append("#").append(i)
                    .append(" class=").append(hexByte(u.getInterfaceClass()))
                    .append(" sub=").append(hexByte(u.getInterfaceSubclass()))
                    .append(" proto=").append(hexByte(u.getInterfaceProtocol()))
                    .append(" ep=").append(u.getEndpointCount());

            for (int e = 0; e < u.getEndpointCount(); e++) {
                UsbEndpoint ep = u.getEndpoint(e);
                s.append(" [")
                        .append(e)
                        .append(":")
                        .append(ep.getDirection() == UsbConstants.USB_DIR_IN ? "IN" : "OUT")
                        .append(",")
                        .append(endpointType(ep.getType()))
                        .append(",")
                        .append(ep.getMaxPacketSize())
                        .append("B]");
            }

            if (i + 1 < d.getInterfaceCount()) s.append(" | ");
        }

        return s.toString();
    }

    private String endpointType(int type) {
        switch (type) {
            case UsbConstants.USB_ENDPOINT_XFER_CONTROL: return "CONTROL";
            case UsbConstants.USB_ENDPOINT_XFER_ISOC: return "ISO";
            case UsbConstants.USB_ENDPOINT_XFER_BULK: return "BULK";
            case UsbConstants.USB_ENDPOINT_XFER_INT: return "INT";
            default: return "UNKNOWN";
        }
    }

    private String recommendation(UsbDevice d) {
        if (isQualcomm(d))
            return "QUALCOMM 9008 is confirmed from the USB VID/PID. Use this screen for identification only.";
        if (isMtkPreloader(d))
            return "MediaTek Preloader identifier detected. Do not assume BROM from USB VID/PID alone.";
        if (hasAdb(d))
            return "ADB interface detected. Android USB debugging authorization is still controlled by the phone.";
        if (looksFastboot(d))
            return "Possible Fastboot identifier detected. Confirm the actual bootloader state before any service action.";
        if (hasMtp(d))
            return "Normal MTP/PTP Android connection. MTP device information can provide a more accurate model name.";
        if (isMtkVendorDevice(d))
            return "MediaTek USB vendor detected, but the current identifiers do not prove Preloader/BROM mode.";
        return "USB device detected. Review VID/PID, interfaces and endpoints before selecting a technician workflow.";
    }

    private int modeColor(String mode) {
        String x = mode.toUpperCase(Locale.US);
        if (x.contains("QUALCOMM") || x.contains("PRELOADER")) return ORANGE;
        if (x.contains("VENDOR") || x.contains("USB /")) return MUTED;
        return GREEN;
    }

    private int detectColor(String value) {
        String x = value.toUpperCase(Locale.US);
        if (x.contains("CONFIRMED") || x.contains("PRESENT")
                || x.contains("DETECTED") || x.contains("MATCH")) return GREEN;
        if (x.contains("POSSIBLE") || x.contains("REQUIRED")
                || x.contains("NOT EXPOSED") || x.contains("NOT LOW-LEVEL")) return ORANGE;
        return MUTED;
    }

    private String readSerial(UsbDevice d) {
        try {
            return safe(d.getSerialNumber());
        } catch (SecurityException e) {
            return "Protected / unavailable";
        } catch (Exception e) {
            return "Unavailable";
        }
    }

    private String safe(String s) {
        return TextUtils.isEmpty(s) ? "Not reported" : s;
    }

    private String hex(int x) {
        return String.format(Locale.US, "0x%04X (%d)", x & 0xFFFF, x);
    }

    private String hexByte(int x) {
        return String.format(Locale.US, "0x%02X", x & 0xFF);
    }

    private String usbClass(int c) {
        switch (c) {
            case UsbConstants.USB_CLASS_STILL_IMAGE: return "Still Image / MTP";
            case UsbConstants.USB_CLASS_COMM: return "Communications";
            case UsbConstants.USB_CLASS_CDC_DATA: return "CDC Data";
            case UsbConstants.USB_CLASS_HID: return "HID";
            case UsbConstants.USB_CLASS_VENDOR_SPEC: return "Vendor Specific";
            default: return hexByte(c);
        }
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 18, 18, 18);
        box.setBackground(panel(PANEL, 26));
        return box;
    }

    private LinearLayout.LayoutParams marginParams() {
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 12);
        return lp;
    }

    private GradientDrawable panel(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        g.setStroke(1, 0x334C6680);
        return g;
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private void addSection(LinearLayout parent, String title) {
        TextView t = text(title, 14, BLUE, true);
        t.setPadding(0, 14, 0, 7);
        parent.addView(t);
    }

    private void addRow(LinearLayout parent, String key, String value) {
        TextView t = text(key + "\n" + value, 13, WHITE, false);
        t.setPadding(0, 5, 0, 7);
        parent.addView(t);
    }

    private void addStatusRow(LinearLayout parent, String key, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(11, 9, 11, 9);
        row.setBackground(panel(PANEL2, 14));

        TextView k = text(key, 12, MUTED, true);
        TextView v = text(value, 12, color, true);

        row.addView(k, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(v);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 3, 0, 3);
        parent.addView(row, lp);
    }

    private void setStatus(String s, int color) {
        if (status == null) return;
        status.setText(s);
        status.setTextColor(color);
    }

    private void appendHistory(String event) {
        String stamp = new java.text.SimpleDateFormat(
                "HH:mm:ss", Locale.US).format(new java.util.Date());
        history.add(0, stamp + "  " + event);

        while (history.size() > 30) history.remove(history.size() - 1);
        updateHistory();
    }

    private void updateHistory() {
        if (historyView == null) return;

        if (history.isEmpty()) {
            historyView.setText("No USB events yet.");
            return;
        }

        StringBuilder s = new StringBuilder();
        for (String h : history) s.append(h).append('\n');
        historyView.setText(s.toString().trim());
    }

    private void fullScan() {
        knownDevices.clear();
        liveDevices.clear();
        currentFingerprint = "";
        lastRenderedDeviceCount = -1;
        reconcileUsbDevices();
        Toast.makeText(this, "Full USB scan completed.", Toast.LENGTH_SHORT).show();
    }

    private void copyReport() {
        if (TextUtils.isEmpty(report)) {
            Toast.makeText(this, "Nothing to copy.", Toast.LENGTH_SHORT).show();
            return;
        }

        android.content.ClipboardManager cm =
                (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        cm.setPrimaryClip(
                ClipData.newPlainText("USB Phone Info Report", report));

        Toast.makeText(this, "Technician report copied.", Toast.LENGTH_SHORT).show();
    }

    private void shareReport() {
        if (TextUtils.isEmpty(report)) {
            Toast.makeText(this, "Nothing to share.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT,
                "USB Phone Info • Advanced Technician Report");
        i.putExtra(Intent.EXTRA_TEXT, report);

        startActivity(Intent.createChooser(i, "Share technician report"));
    }

    private UsbDevice getDevice(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra(
                    UsbManager.EXTRA_DEVICE, UsbDevice.class);
        }
        return intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
    }

    @Override
    protected void onDestroy() {
        stopMonitor();

        try { unregisterReceiver(usbReceiver); }
        catch (Exception ignored) {}

        worker.shutdownNow();

        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }

        super.onDestroy();
    }
}
