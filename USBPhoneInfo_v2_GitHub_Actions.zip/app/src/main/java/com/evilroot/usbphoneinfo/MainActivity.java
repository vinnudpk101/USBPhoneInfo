package com.evilroot.usbphoneinfo;

import android.app.*;
import android.content.*;
import android.hardware.usb.*;
import android.mtp.*;
import android.os.*;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import java.util.*;

public class MainActivity extends Activity {
    static final String ACTION="com.evilroot.usbphoneinfo.USB_PERMISSION";
    UsbManager manager; LinearLayout cards; TextView status; String report="";
    BroadcastReceiver receiver=new BroadcastReceiver(){
        public void onReceive(Context c,Intent i){
            String a=i.getAction();
            if(ACTION.equals(a)){
                UsbDevice d=getDevice(i);
                if(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false)&&d!=null) render(d);
                else status.setText("USB permission denied.");
            } else if(UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)||UsbManager.ACTION_USB_DEVICE_DETACHED.equals(a)) scan();
        }
    };
    UsbDevice getDevice(Intent i){
        if(Build.VERSION.SDK_INT>=33)return i.getParcelableExtra(UsbManager.EXTRA_DEVICE,UsbDevice.class);
        return i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
    }
    public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        manager=(UsbManager)getSystemService(USB_SERVICE); cards=findViewById(R.id.cards); status=findViewById(R.id.status);
        findViewById(R.id.scan).setOnClickListener(v->scan());
        findViewById(R.id.copy).setOnClickListener(v->copyReport());
        IntentFilter f=new IntentFilter(); f.addAction(ACTION); f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED); f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
        scan();
    }
    public void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception e){} super.onDestroy();}
    void scan(){
        cards.removeAllViews(); report="";
        Map<String,UsbDevice> ds=manager.getDeviceList();
        if(ds.isEmpty()){status.setText("No USB device detected.");return;}
        status.setText("Detected "+ds.size()+" USB device(s).");
        for(UsbDevice d:ds.values()){
            if(manager.hasPermission(d))render(d); else {
                PendingIntent p=PendingIntent.getBroadcast(this, d.getDeviceId(),
                    new Intent(ACTION).setPackage(getPackageName()),
                    PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                manager.requestPermission(d,p);
            }
        }
    }
    void render(UsbDevice d){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(16,16,16,16);
        box.setBackgroundColor(0xffffffff);
        add(box,"Device",safe(d.getDeviceName()));
        add(box,"Manufacturer",safe(d.getManufacturerName()));
        add(box,"Product / Model",safe(d.getProductName()));
        add(box,"VID",hex(d.getVendorId()));
        add(box,"PID",hex(d.getProductId()));
        add(box,"USB class",usbClass(d.getDeviceClass()));
        add(box,"Interfaces",String.valueOf(d.getInterfaceCount()));
        String serial="Not available";
        try{serial=safe(d.getSerialNumber());}catch(Exception ignored){}
        add(box,"USB serial",serial);

        String mode=classify(d);
        add(box,"Likely USB mode",mode);
        add(box,"ADB", "Not directly queried / requires authorized ADB");
        add(box,"Fastboot", detectFastboot(d));
        add(box,"Qualcomm 9008", detectQualcomm(d));
        add(box,"MediaTek Preloader/BROM", detectMtk(d));
        add(box,"MTP", mtp(d));

        cards.addView(box,new LinearLayout.LayoutParams(-1,-2));
        report += "\n=== USB DEVICE ===\n"+textOf(box)+"\n";
    }
    String textOf(View v){
        if(!(v instanceof ViewGroup))return "";
        StringBuilder s=new StringBuilder();
        ViewGroup g=(ViewGroup)v;
        for(int i=0;i<g.getChildCount();i++){
            View x=g.getChildAt(i);
            if(x instanceof TextView)s.append(((TextView)x).getText()).append('\n');
        }
        return s.toString();
    }
    void add(LinearLayout p,String k,String v){
        TextView t=new TextView(this); t.setText(k+": "+v); t.setTextSize(15); t.setPadding(0,5,0,5); p.addView(t);
    }
    String safe(String s){return TextUtils.isEmpty(s)?"Not reported":s;}
    String hex(int x){return String.format(Locale.US,"0x%04X (%d)",x&65535,x);}
    String usbClass(int c){
        if(c==UsbConstants.USB_CLASS_VENDOR_SPEC)return "Vendor Specific";
        if(c==UsbConstants.USB_CLASS_STILL_IMAGE)return "Still Image / MTP";
        if(c==UsbConstants.USB_CLASS_COMM)return "Communications";
        if(c==UsbConstants.USB_CLASS_CDC_DATA)return "CDC Data";
        if(c==UsbConstants.USB_CLASS_HID)return "HID";
        return "0x"+Integer.toHexString(c);
    }
    String classify(UsbDevice d){
        for(int i=0;i<d.getInterfaceCount();i++){
            UsbInterface u=d.getInterface(i);
            if(u.getInterfaceClass()==UsbConstants.USB_CLASS_STILL_IMAGE)return "MTP/PTP";
        }
        return usbClass(d.getDeviceClass());
    }
    String detectFastboot(UsbDevice d){
        // Common Google/Android fastboot interface patterns vary by vendor.
        if(d.getVendorId()==0x18D1)return "Possible (Google/Android VID)";
        return "Not confirmed";
    }
    String detectQualcomm(UsbDevice d){
        // Qualcomm HS-USB QDLoader 9008 commonly uses VID 0x05C6 and PID 0x9008.
        return (d.getVendorId()==0x05C6 && d.getProductId()==0x9008) ? "DETECTED (VID 05C6 / PID 9008)" : "Not detected";
    }
    String detectMtk(UsbDevice d){
        // Common MediaTek VCOM/preloader IDs include 0x0E8D. Exact PIDs vary by device.
        return d.getVendorId()==0x0E8D ? "POSSIBLE MediaTek (VID 0E8D)" : "Not detected";
    }
    String mtp(UsbDevice d){
        boolean yes=false;
        for(int i=0;i<d.getInterfaceCount();i++){
            int c=d.getInterface(i).getInterfaceClass();
            if(c==UsbConstants.USB_CLASS_STILL_IMAGE)yes=true;
        }
        if(!yes)return "Not detected";
        UsbDeviceConnection con=null; MtpDevice m=null;
        try{
            con=manager.openDevice(d); if(con==null)return "Detected, connection unavailable";
            m=new MtpDevice(d); if(!m.open(con))return "Detected, MTP open failed";
            MtpDeviceInfo x=m.getDeviceInfo();
            if(x==null)return "Detected, no device info";
            return "Detected | "+safe(x.getManufacturer())+" | "+safe(x.getModel())+" | Android USB/MTP";
        }catch(Exception e){return "Detected, unavailable";}
        finally{try{if(m!=null)m.close();}catch(Exception e){} try{if(con!=null)con.close();}catch(Exception e){}}
    }
    void copyReport(){
        if(report.length()==0){Toast.makeText(this,"Nothing to copy.",Toast.LENGTH_SHORT).show();return;}
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("USB Phone Info",report));
        Toast.makeText(this,"Information copied.",Toast.LENGTH_SHORT).show();
    }
}
