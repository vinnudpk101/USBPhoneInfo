# USB Phone Info v2 — Technician Edition

This Android Studio project is designed for an Android phone acting as USB host/OTG.

Features:
- USB hot-plug scan
- Manufacturer/product/model strings
- VID/PID
- USB class/interfaces
- USB serial where Android permits
- MTP device information
- USB mode classification
- Qualcomm 9008 heuristic (05C6:9008)
- MediaTek heuristic (0E8D)
- Fastboot indication using common Google/Android VID (not a protocol proof)
- ADB status note
- Copy all detected information

Limitations:
- Android cannot always inspect another phone's private Android properties without ADB authorization.
- ADB requires USB debugging and authorization on the customer's phone.
- Fastboot, Qualcomm EDL/9008, MediaTek Preloader/BROM and vendor download modes are low-level USB protocols. This v2 identifies common USB signatures where possible; it does not perform flashing, unlocking, FRP bypass, or write operations.
- Some phones expose no useful data when locked or when the display/USB configuration prevents data access.
- A completely dead phone cannot be identified through USB.

Build with Android Studio using JDK 17. Build > Generate App Bundles or APKs > Generate APKs.


## GitHub Actions build

The workflow in `.github/workflows/build-apk.yml` builds the debug APK in GitHub Actions.

Important: Android Studio/Gradle should generate and commit the standard Gradle wrapper files:
- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.jar`
- `gradle/wrapper/gradle-wrapper.properties`

After those files are present in the repository, use **Actions → Build Android APK → Run workflow**. The APK will appear as an artifact named `USBPhoneInfo-v2-debug`.
