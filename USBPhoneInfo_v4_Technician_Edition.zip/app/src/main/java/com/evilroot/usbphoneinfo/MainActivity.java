package com.evilroot.usbphoneinfo;

import android.app.*;
import android.content.*;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.*;
import android.mtp.MtpDevice;
import android.mtp.MtpDeviceInfo;
import android.os.*;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final String ACTION = "com.evilroot.usbphoneinfo.USB_PERMISSION";

    final int GREEN = 0xFF168A4A;
    final int GREEN_BG = 0xFFE8F7EE;
    final int BLUE = 0xFF246BCE;
    final int ORANGE = 0xFFC77700;
    final int RED = 0xFFC0392B;
    final int TEXT = 0xFF18212B;
    final int MUTED = 0xFF5F6B78;

    UsbManager manager;
    LinearLayout cards;
    TextView status;
    String report = "";

    final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (ACTION.equals(a)) {
                UsbDevice d = getDevice(i);
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && d != null)
                    render(d);
                else
                    setStatus("USB permission denied.", RED);
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(a)
                    || UsbManager.ACTION_USB_DEVICE_DETACHED.equals(a)) {
                scan();
            }
        }
    };

    UsbDevice getDevice(Intent i) {
        if (Build.VERSION.SDK_INT >= 33)
            return i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice.class);
        return i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        manager = (UsbManager)getSystemService(USB_SERVICE);
        cards = findViewById(R.id.cards);
        status = findViewById(R.id.status);

        findViewById(R.id.scan).setOnClickListener(v -> scan());
        findViewById(R.id.copy).setOnClickListener(v -> copyReport());
        findViewById(R.id.share).setOnClickListener(v -> shareReport());

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION);
        f.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        else
            registerReceiver(receiver, f);

        scan();
    }

    @Override public void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    void setStatus(String text, int color) {
        status.setText(text);
        status.setTextColor(color);
    }

    GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    void scan() {
        cards.removeAllViews();
        report = "";
        Map<String,UsbDevice> ds = manager.getDeviceList();

        if (ds.isEmpty()) {
            setStatus("●  NO USB DEVICE DETECTED", MUTED);
            return;
        }

        setStatus("●  " + ds.size() + " USB DEVICE(S) DETECTED", GREEN);

        for (UsbDevice d : ds.values()) {
            if (manager.hasPermission(d)) render(d);
            else {
                PendingIntent p = PendingIntent.getBroadcast(
                        this,
                        Math.abs(d.getDeviceId()),
                        new Intent(ACTION).setPackage(getPackageName()),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                manager.requestPermission(d, p);
            }
        }
    }

    void render(UsbDevice d) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 18, 18, 18);
        box.setBackground(bg(0xFFFDFEFF, 26));

        String model = safe(d.getProductName());
        String manufacturer = safe(d.getManufacturerName());
        String mode = classifyMode(d);

        TextView connected = tv("●  USB DEVICE CONNECTED", 13, GREEN, true);
        connected.setPadding(0, 0, 0, 8);
        box.addView(connected);

        TextView modelView = tv(model, 25, GREEN, true);
        box.addView(modelView);

        TextView brandView = tv(manufacturer, 15, MUTED, false);
        brandView.setPadding(0, 2, 0, 14);
        box.addView(brandView);

        addSection(box, "DEVICE / USB");
        addRow(box, "Device path", safe(d.getDeviceName()));
        addRow(box, "VID", hex(d.getVendorId()));
        addRow(box, "PID", hex(d.getProductId()));
        addRow(box, "USB class", usbClass(d.getDeviceClass()));
        addRow(box, "Interfaces", String.valueOf(d.getInterfaceCount()));
        addRow(box, "USB serial", readSerial(d));

        addSection(box, "MODE DETECTION");
        addModeRow(box, "Primary USB mode", mode, modeColor(mode));
        addModeRow(box, "MTP / PTP", mtp(d), detectColor(mtp(d)));
        addModeRow(box, "ADB", detectAdb(d), detectColor(detectAdb(d)));
        addModeRow(box, "Fastboot", detectFastboot(d), detectColor(detectFastboot(d)));
        addModeRow(box, "Qualcomm 9008 / EDL", detectQualcomm(d), detectColor(detectQualcomm(d)));
        addModeRow(box, "MediaTek Preloader / BROM", detectMtkService(d), detectColor(detectMtkService(d)));

        addSection(box, "INTERFACES");
        addRow(box, "Interface details", interfaceDetails(d));

        addSection(box, "TECHNICIAN RESULT");
        TextView rec = tv(recommendation(d), 14, BLUE, true);
        rec.setPadding(0, 8, 0, 4);
        box.addView(rec);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 12);
        cards.addView(box, lp);

        report += "\n=== USB PHONE INFO TECHNICIAN 4.0 ===\n";
        report += "MODEL: " + model + "\n";
        report += "MANUFACTURER: " + manufacturer + "\n";
        report += "VID: " + hex(d.getVendorId()) + "\n";
        report += "PID: " + hex(d.getProductId()) + "\n";
        report += "USB MODE: " + mode + "\n";
        report += "MTP/PTP: " + mtp(d) + "\n";
        report += "ADB: " + detectAdb(d) + "\n";
        report += "FASTBOOT: " + detectFastboot(d) + "\n";
        report += "QUALCOMM 9008/EDL: " + detectQualcomm(d) + "\n";
        report += "MEDIATEK SERVICE: " + detectMtkService(d) + "\n";
        report += "INTERFACES: " + interfaceDetails(d) + "\n";
        report += "TECHNICIAN RESULT: " + recommendation(d) + "\n";
    }

    void addSection(LinearLayout p, String s) {
        TextView t = tv(s, 15, BLUE, true);
        t.setPadding(0, 12, 0, 5);
        p.addView(t);
    }

    void addRow(LinearLayout p, String k, String v) {
        TextView t = tv(k + "\n" + v, 14, TEXT, false);
        t.setPadding(0, 5, 0, 5);
        p.addView(t);
    }

    void addModeRow(LinearLayout p, String k, String v, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(10, 8, 10, 8);
        row.setBackground(bg(color == GREEN ? GREEN_BG : 0xFFF4F6F8, 12));

        TextView key = tv(k, 13, MUTED, false);
        TextView val = tv(v, 14, color, true);
        row.addView(key);
        row.addView(val);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 3, 0, 5);
        p.addView(row, lp);
    }

    int modeColor(String mode) {
        String x = mode.toUpperCase(Locale.US);
        if (x.contains("QUALCOMM") || x.contains("MEDIATEK")) return ORANGE;
        if (x.contains("USB / VENDOR")) return MUTED;
        return GREEN;
    }

    int detectColor(String value) {
        String x = value.toUpperCase(Locale.US);
        if (x.contains("DETECTED") && !x.contains("NOT DETECTED") && !x.contains("NOT CONFIRMED"))
            return GREEN;
        if (x.contains("POSSIBLE") || x.contains("NOT CONFIRMED") || x.contains("REQUIRES"))
            return ORANGE;
        return MUTED;
    }

    String safe(String s) { return TextUtils.isEmpty(s) ? "Not reported" : s; }

    String readSerial(UsbDevice d) {
        try { return safe(d.getSerialNumber()); }
        catch (Exception e) { return "Protected / unavailable"; }
    }

    String hex(int x) {
        return String.format(Locale.US, "0x%04X (%d)", x & 65535, x);
    }

    String usbClass(int c) {
        switch (c) {
            case UsbConstants.USB_CLASS_VENDOR_SPEC: return "Vendor Specific";
            case UsbConstants.USB_CLASS_STILL_IMAGE: return "Still Image / MTP";
            case UsbConstants.USB_CLASS_COMM: return "Communications";
            case UsbConstants.USB_CLASS_CDC_DATA: return "CDC Data";
            case UsbConstants.USB_CLASS_HID: return "HID";
            default: return "0x" + Integer.toHexString(c);
        }
    }

    String classifyMode(UsbDevice d) {
        if (isQualcomm(d)) return "QUALCOMM 9008 / EDL";
        if (isMtkService(d)) return "MEDIATEK PRELOADER / BROM";
        if (hasAdbInterface(d)) return "ADB / ANDROID";
        if (looksFastboot(d)) return "FASTBOOT";
        if (hasMtpInterface(d)) return "MTP / PTP";
        return "USB / VENDOR MODE";
    }

    boolean hasMtpInterface(UsbDevice d) {
        for (int i=0; i<d.getInterfaceCount(); i++)
            if (d.getInterface(i).getInterfaceClass() == UsbConstants.USB_CLASS_STILL_IMAGE) return true;
        return false;
    }

    boolean hasAdbInterface(UsbDevice d) {
        for (int i=0; i<d.getInterfaceCount(); i++) {
            UsbInterface u = d.getInterface(i);
            if (u.getInterfaceClass() == 0xFF && u.getInterfaceSubclass() == 0x42
                    && u.getInterfaceProtocol() == 0x01 && u.getEndpointCount() >= 2) return true;
        }
        return false;
    }

    boolean looksFastboot(UsbDevice d) {
        int v = d.getVendorId(), p = d.getProductId();
        return v == 0x18D1 && (p == 0x4EE0 || p == 0x4EE1 || p == 0x4EE2 || p == 0x4EE7);
    }

    boolean isQualcomm(UsbDevice d) {
        return d.getVendorId() == 0x05C6 && d.getProductId() == 0x9008;
    }

    boolean isMtkService(UsbDevice d) {
        if (d.getVendorId() != 0x0E8D) return false;
        int p = d.getProductId();
        if (p == 0x2008 || p == 0x2000) return false;
        return p == 0x0003 || p == 0x0004 || p == 0x0005
                || p == 0x2001 || p == 0x2002 || p == 0x2003
                || p == 0x2004 || p == 0x2007 || p == 0x200B
                || hasVendorInterface(d);
    }

    boolean hasVendorInterface(UsbDevice d) {
        for (int i=0; i<d.getInterfaceCount(); i++)
            if (d.getInterface(i).getInterfaceClass() == 0xFF) return true;
        return false;
    }

    String detectAdb(UsbDevice d) {
        if (!hasAdbInterface(d)) return "Not detected";
        return "ADB interface detected; authorization required";
    }

    String detectFastboot(UsbDevice d) {
        return looksFastboot(d) ? "Detected from USB identifiers" : "Not confirmed";
    }

    String detectQualcomm(UsbDevice d) {
        return isQualcomm(d) ? "DETECTED (VID 05C6 / PID 9008)" : "Not detected";
    }

    String detectMtkService(UsbDevice d) {
        if (isMtkService(d))
            return "POSSIBLE / MediaTek service interface";
        if (d.getVendorId() == 0x0E8D)
            return "MediaTek USB vendor ID; current PID looks like Android/MTP";
        return "Not detected";
    }

    String interfaceDetails(UsbDevice d) {
        StringBuilder s = new StringBuilder();
        for (int i=0; i<d.getInterfaceCount(); i++) {
            UsbInterface u = d.getInterface(i);
            s.append("#").append(i)
             .append(" class=").append(String.format(Locale.US, "0x%02X", u.getInterfaceClass()))
             .append(" subclass=").append(String.format(Locale.US, "0x%02X", u.getInterfaceSubclass()))
             .append(" protocol=").append(String.format(Locale.US, "0x%02X", u.getInterfaceProtocol()))
             .append(" endpoints=").append(u.getEndpointCount());
            if (i + 1 < d.getInterfaceCount()) s.append(" | ");
        }
        return s.toString();
    }

    String mtp(UsbDevice d) {
        if (!hasMtpInterface(d)) return "Not detected";
        UsbDeviceConnection con = null;
        MtpDevice m = null;
        try {
            con = manager.openDevice(d);
            if (con == null) return "Detected, connection unavailable";
            m = new MtpDevice(d);
            if (!m.open(con)) return "Detected, MTP open failed";
            MtpDeviceInfo x = m.getDeviceInfo();
            if (x == null) return "Detected, no device info";
            return "Detected | " + safe(x.getManufacturer()) + " | "
                    + safe(x.getModel()) + " | Android USB/MTP";
        } catch (Exception e) {
            return "Detected, unavailable";
        } finally {
            try { if (m != null) m.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }

    String recommendation(UsbDevice d) {
        if (isQualcomm(d)) return "Qualcomm 9008 confirmed. Continue with EDL diagnostics.";
        if (isMtkService(d)) return "MediaTek service interface detected. Check Preloader/BROM state.";
        if (hasAdbInterface(d)) return "ADB interface found. Authorize USB debugging for deeper diagnostics.";
        if (looksFastboot(d)) return "Fastboot detected. Inspect bootloader identifiers.";
        if (hasMtpInterface(d)) return "Normal Android/MTP connection. Enable USB debugging for deeper ADB diagnostics.";
        return "Inspect USB VID/PID and interface class before selecting a service mode.";
    }

    void copyReport() {
        if (report.length() == 0) {
            Toast.makeText(this, "Nothing to copy.", Toast.LENGTH_SHORT).show();
            return;
        }
        android.content.ClipboardManager cm =
                (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("USB Phone Info", report));
        Toast.makeText(this, "Technician report copied.", Toast.LENGTH_SHORT).show();
    }

    void shareReport() {
        if (report.length() == 0) {
            Toast.makeText(this, "Nothing to share.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "USB Phone Info Technician 4.0 Report");
        i.putExtra(Intent.EXTRA_TEXT, report);
        startActivity(Intent.createChooser(i, "Share technician report"));
    }
}
